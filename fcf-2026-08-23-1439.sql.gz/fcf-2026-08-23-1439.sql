--
-- PostgreSQL database dump
--

\restrict kybtpc6FgLeWqIqjp3dDgxgodrhqEYN0D5X5YvRr5va1lJ4a4zfFwJ38kXD3rR0

-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: fcf
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO fcf;

--
-- Name: folder_items; Type: TABLE; Schema: public; Owner: fcf
--

CREATE TABLE public.folder_items (
    id integer NOT NULL,
    folder_id integer NOT NULL,
    ein character varying(9) NOT NULL,
    note text,
    added_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.folder_items OWNER TO fcf;

--
-- Name: folder_items_id_seq; Type: SEQUENCE; Schema: public; Owner: fcf
--

CREATE SEQUENCE public.folder_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.folder_items_id_seq OWNER TO fcf;

--
-- Name: folder_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fcf
--

ALTER SEQUENCE public.folder_items_id_seq OWNED BY public.folder_items.id;


--
-- Name: folders; Type: TABLE; Schema: public; Owner: fcf
--

CREATE TABLE public.folders (
    id integer NOT NULL,
    team_id integer NOT NULL,
    name character varying(200) NOT NULL,
    created_by integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.folders OWNER TO fcf;

--
-- Name: folders_id_seq; Type: SEQUENCE; Schema: public; Owner: fcf
--

CREATE SEQUENCE public.folders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.folders_id_seq OWNER TO fcf;

--
-- Name: folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fcf
--

ALTER SEQUENCE public.folders_id_seq OWNED BY public.folders.id;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: fcf
--

CREATE TABLE public.teams (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.teams OWNER TO fcf;

--
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: fcf
--

CREATE SEQUENCE public.teams_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.teams_id_seq OWNER TO fcf;

--
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fcf
--

ALTER SEQUENCE public.teams_id_seq OWNED BY public.teams.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: fcf
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(320) NOT NULL,
    team_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO fcf;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: fcf
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO fcf;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fcf
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: folder_items id; Type: DEFAULT; Schema: public; Owner: fcf
--

ALTER TABLE ONLY public.folder_items ALTER COLUMN id SET DEFAULT nextval('public.folder_items_id_seq'::regclass);


--
-- Name: folders id; Type: DEFAULT; Schema: public; Owner: fcf
--

ALTER TABLE ONLY public.folders ALTER COLUMN id SET DEFAULT nextval('public.folders_id_seq'::regclass);


--
-- Name: teams id; Type: DEFAULT; Schema: public; Owner: fcf
--

ALTER TABLE ONLY public.teams ALTER COLUMN id SET DEFAULT nextval('public.teams_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: fcf
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: fcf
--

COPY public.alembic_version (version_num) FROM stdin;
0001_accounts
\.


--
-- Data for Name: folder_items; Type: TABLE DATA; Schema: public; Owner: fcf
--

COPY public.folder_items (id, folder_id, ein, note, added_by, created_at) FROM stdin;
3	5	350868122	\N	1	2026-08-22 21:42:39.963054+00
\.


--
-- Data for Name: folders; Type: TABLE DATA; Schema: public; Owner: fcf
--

COPY public.folders (id, team_id, name, created_by, created_at) FROM stdin;
3	1	Favorites	1	2026-08-18 23:30:13.535485+00
4	1	Christian Aid Mission	1	2026-08-18 23:30:17.790009+00
5	1	Test	1	2026-08-22 21:42:39.714817+00
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: fcf
--

COPY public.teams (id, name, created_at) FROM stdin;
1	Foundation Explorer	2026-08-18 22:40:26.095954+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: fcf
--

COPY public.users (id, email, team_id, created_at, last_seen_at) FROM stdin;
2	lesherda@wofford.edu	1	2026-08-18 23:29:46.763959+00	2026-08-18 23:29:56.420797+00
4	mr.frace@gmail.com	1	2026-08-20 15:30:55.744883+00	2026-08-20 15:30:55.744883+00
3	info@flagshipequip.com	1	2026-08-19 16:56:01.778742+00	2026-08-21 12:39:41.891576+00
1	drake.lesher@gmail.com	1	2026-08-18 23:25:50.189084+00	2026-08-23 02:54:20.483467+00
\.


--
-- Name: folder_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fcf
--

SELECT pg_catalog.setval('public.folder_items_id_seq', 3, true);


--
-- Name: folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fcf
--

SELECT pg_catalog.setval('public.folders_id_seq', 5, true);


--
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fcf
--

SELECT pg_catalog.setval('public.teams_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fcf
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: fcf
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: folder_items folder_items_pkey; Type: CONSTRAINT; Schema: public; Owner: fcf
--

ALTER TABLE ONLY public.folder_items
    ADD CONSTRAINT folder_items_pkey PRIMARY KEY (id);


--
-- Name: folders folders_pkey; Type: CONSTRAINT; Schema: public; Owner: fcf
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_pkey PRIMARY KEY (id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: fcf
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: folder_items uq_folder_items_folder_ein; Type: CONSTRAINT; Schema: public; Owner: fcf
--

ALTER TABLE ONLY public.folder_items
    ADD CONSTRAINT uq_folder_items_folder_ein UNIQUE (folder_id, ein);


--
-- Name: users uq_users_email; Type: CONSTRAINT; Schema: public; Owner: fcf
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uq_users_email UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: fcf
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_folder_items_folder_id; Type: INDEX; Schema: public; Owner: fcf
--

CREATE INDEX ix_folder_items_folder_id ON public.folder_items USING btree (folder_id);


--
-- Name: ix_folders_team_id; Type: INDEX; Schema: public; Owner: fcf
--

CREATE INDEX ix_folders_team_id ON public.folders USING btree (team_id);


--
-- Name: ix_users_team_id; Type: INDEX; Schema: public; Owner: fcf
--

CREATE INDEX ix_users_team_id ON public.users USING btree (team_id);


--
-- Name: uq_folders_team_lower_name; Type: INDEX; Schema: public; Owner: fcf
--

CREATE UNIQUE INDEX uq_folders_team_lower_name ON public.folders USING btree (team_id, lower((name)::text));


--
-- Name: folder_items folder_items_added_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fcf
--

ALTER TABLE ONLY public.folder_items
    ADD CONSTRAINT folder_items_added_by_fkey FOREIGN KEY (added_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: folder_items folder_items_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fcf
--

ALTER TABLE ONLY public.folder_items
    ADD CONSTRAINT folder_items_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.folders(id) ON DELETE CASCADE;


--
-- Name: folders folders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fcf
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: folders folders_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fcf
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE CASCADE;


--
-- Name: users users_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fcf
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict kybtpc6FgLeWqIqjp3dDgxgodrhqEYN0D5X5YvRr5va1lJ4a4zfFwJ38kXD3rR0

